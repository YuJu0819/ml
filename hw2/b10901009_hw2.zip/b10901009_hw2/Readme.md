Use seed 41 1209 819 to create three csv
and ensemble by voting

need to rename the prediction file first
