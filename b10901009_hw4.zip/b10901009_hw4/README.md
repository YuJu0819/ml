use different number of d_model to create three output and then ensemble
